<footer class="main-footer">
    <strong>Copyright &copy; {{ date("Y")}}<a> ES Creative 工業株式会社</a>.</strong>
      All rights reserved.
</footer>