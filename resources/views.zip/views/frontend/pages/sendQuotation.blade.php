@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<h1>Send Quotation</h1>
    
@endsection