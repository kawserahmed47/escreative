@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')
@include('frontend.layouts.services')
@include('frontend.layouts.banner')
@endsection