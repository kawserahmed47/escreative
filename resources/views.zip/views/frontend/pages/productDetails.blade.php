@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<h1>Product Details</h1>
    
@endsection