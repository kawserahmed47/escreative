<section id="page-banner" data-bg-image="media/banner/5.jpg" data-parallax="image">
    <div class="overlay"></div>
    <div class="container text-center">
        <div class="banner-content">
            <h2 class="page-title">...</h2>
            <h5 class="text-light">Home / @if($title){{$title}}@endif</h5>
        </div>
    </div>
</section>