<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ES Creative</title>
</head>
<body>
<p>{{$details}}</p>

<br><br>
<span> NB:For Details Visit <a href="https://escreative-industry.com">www.escreative-industry.com</a></span>
</body>
</html>