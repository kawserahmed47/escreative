<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('frontend.pages.index');
// });

Route::get('/','FrontController@index')->name('index');

Route::get('/about-us','FrontController@about')->name('about');

Route::get('/profile','FrontController@profile')->name('profile');

Route::get('/ceo-message','FrontController@ceoMessage')->name('ceoMessage');

Route::get('/mission','FrontController@mission')->name('mission');

Route::get('/vision','FrontController@vision')->name('vision');

Route::get('/history','FrontController@history')->name('history');

Route::get('/gallery','FrontController@gallery')->name('gallery');

Route::get('/team','FrontController@team')->name('team');

Route::get('/faq','FrontController@faq')->name('faq');

Route::get('/services','FrontController@services')->name('services');

Route::get('/service-details','FrontController@serviceDetails')->name('serviceDetails');

Route::get('/products','FrontController@products')->name('products');

Route::get('/product-details','FrontController@productDetails')->name('productDetails');

Route::get('/projects','FrontController@projects')->name('projects');

Route::get('/project-details','FrontController@projectDetails')->name('projectDetails');

Route::get('/news','FrontController@news')->name('news');

Route::get('/news-details','FrontController@newsDetails')->name('newsDetails');

Route::get('/contact','FrontController@contact')->name('contact');

Route::post('/sendMessage','FrontController@sendMessage')->name('sendMessage');

Route::get('/quotation','FrontController@quotation')->name('quotation');

Route::post('/sendQuotation','FrontController@sendQuotation')->name('sendQuotation');
