@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<h1>News Details</h1>
    
@endsection