@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')
<br><br>
<div class="container">
    <div class="row">
        <div class="col-md-2">

        </div>

        <div class="col-md-8">
            <div class="contact">
                <h2 class="contact-title">Get Quotation</h2>
                <p>If you want to quotation, please see our address or call our number or send us
                    on our email, we will contact with you for our own business, so don’t worrie we are
                    beside you to help you.</p>
                <form action="" id="" method="post">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="name-field"><input
                                    class="form-control contact-form-field cffield-upper" name="fname"
                                    id="form-name" placeholder="Name" type="text" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="email-field"><input
                                    class="form-control contact-form-field cffield-upper" name="femail"
                                    id="form-email" placeholder="Email" type="email" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="name-field"><input
                                    class="form-control contact-form-field cffield-upper" name="fname"
                                    id="form-name" placeholder="Mobile" type="text" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="email-field"><input
                                    class="form-control contact-form-field cffield-upper" name="femail"
                                    id="form-email" placeholder="Address" type="text" required=""></div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group" id="subject-field"><input
                                    class="form-control contact-form-field cffield-upper"
                                    name="fsubject" id="form-subject" placeholder="Types of Query" type="text"
                                    required=""></div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group form-text text-center" id="message-field"><textarea
                                    cols="30" rows="6" placeholder="Your Query"
                                    class="form-control contact-form-field" name="fmessage"
                                    id="form-message" required=""></textarea>
                                {{-- <grammarly-btn>
                                    <div style="visibility: hidden; z-index: 2"
                                        class="_e725ae-textarea_btn _e725ae-not_focused"
                                        data-grammarly-reactid=".0">
                                        <div class="_e725ae-transform_wrap"
                                            data-grammarly-reactid=".0.0">
                                            <div title="Protected by Grammarly" class="_e725ae-status"
                                                data-grammarly-reactid=".0.0.0">&nbsp;</div>
                                        </div>
                                    </div>
                                </grammarly-btn> --}}
                            </div>
                        </div>
                        <div class="col-md-12"><button class="dt-btn" type="submit">Send</button></div>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-2">

        </div>

    </div>

</div>
<br><br>
    
@endsection