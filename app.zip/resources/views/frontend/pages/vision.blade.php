@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')
<br><br>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="{{asset('public/frontend/media/resource/vision.jpg')}}" alt="Mission Preview">


            </div>
            <div class="col-md-6">
                <h3 class="p-3">Vision</h3>
                <hr>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius obcaecati odio doloremque repellat numquam, cum esse fuga exercitationem temporibus amet nemo unde itaque et recusandae nostrum ipsum blanditiis, porro facere?</p>
            </div>

            

        </div>
    </div>
</section>
<br><br>
@include('frontend.layouts.banner')
    
@endsection