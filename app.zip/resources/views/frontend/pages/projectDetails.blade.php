@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')


        
<section id="project_single" data-carousel="swiper">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <aside class="service-widgets">
                    <h3 class="widget-title">What We Do?</h3>
                    <ul class="servile-link">

                        <li><a href="{{route('serviceDetails')}}">住宅リフォームの施工・管理</a></li>
                        <li><a href="{{route('serviceDetails')}}">リフォーム後のメンテナンス</a></li>
                        <li><a href="{{route('serviceDetails')}}">内装工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">防犯工事</a></li>
                        <li><a href="{{route('serviceDetails')}}"> 外装工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}">防火工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}"> 付帯設備工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">■ 耐震補強</a></li>
                        
                    </ul>
                </aside>
            
               @include('frontend.layouts.gallery')
            </div>
            <div class="col-md-9">
                <div class="projece-single">
                    <div class="thumbnail-container gallery-top" data-swiper="container" data-initial="3"
                        data-loop="true" data-looped="5" data-effect="fade" data-crossfade="true">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/11.jpg" alt="Thumbnail"></div>
                            <div class="swiper-slide clearfix"><img src="{{asset('public/frontend/media')}}/recent-work/10.jpg"
                                    alt="Thumbnail"></div>
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/12.jpg" alt="Thumbnail"></div>
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/13.jpg" alt="Thumbnail"></div>
                        </div>
                    </div>
                    <div class="thumbnail-container gallery-thumbs" data-swiper="ascontrol" data-initial="2"
                        data-items="4" data-space="30" data-click-to-slide="true" data-loop="true"
                        data-looped="4" data-direction="horizontal">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/14.jpg" alt="Thumbnail"></div>
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/15.jpg" alt="Thumbnail"></div>
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/16.jpg" alt="Thumbnail"></div>
                            <div class="swiper-slide"><img src="{{asset('public/frontend/media')}}/recent-work/17.jpg" alt="Thumbnail"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7">
                        <div class="project-details">
                            <h3 class="project-title">Project Driscription</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                Duis aute irure dolor in reprehenderit in voluptate</p>
                            <h3 class="project-title">Project Engeneear</h3>
                            <div class="project-eng clearfix">
                                <div class="engeneer"><img src="{{asset('public/frontend/media')}}/recent-work/18.jpg" alt="Enge">
                                    <p class="name">Elizabeth Jones</p>
                                    <p class="position">Art Director</p>
                                </div>
                                <div class="engeneer"><img src="{{asset('public/frontend/media')}}/recent-work/19.jpg" alt="Enge">
                                    <p class="name">Elizabeth Jones</p>
                                    <p class="position">Art Director</p>
                                </div>
                                <div class="engeneer"><img src="{{asset('public/frontend/media')}}/recent-work/20.jpg" alt="Enge">
                                    <p class="name">Elizabeth Jones</p>
                                    <p class="position">Art Director</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="project-details">
                            <h3 class="project-title">Client Feedback</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                nostrud exercitation ullamco laboris nisi.</p>
                            <table class="details">
                                <tr>
                                    <td>Client name :</td>
                                    <td>Someone</td>
                                </tr>
                                <tr>
                                    <td>Start Date :</td>
                                    <td>1st sep 2017</td>
                                </tr>
                                <tr>
                                    <td>End Date :</td>
                                    <td>1st sep 2018</td>
                                </tr>
                                <tr>
                                    <td>Budget :</td>
                                    <td>$900000</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


    
@endsection