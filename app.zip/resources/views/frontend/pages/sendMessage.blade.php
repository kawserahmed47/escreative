@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<h1>Send Message</h1>
    
@endsection