@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<div class="container mt-3">
    <div class="row">
        <div class="col">
            <aside class="widget widget_archive">
              
                <div class="gallery">
                    <a href="{{asset('public/frontend/media')}}/footer/2.jpg"><img style="height: 200px; width:210px" src="{{asset('public/frontend/media')}}/footer/2.jpg" alt=""></a>

                    <a href="{{asset('public/frontend/media')}}/footer/3.jpg"><img style="height: 200px; width:210px" src="{{asset('public/frontend/media')}}/footer/3.jpg" alt=""></a>

                    <a href="{{asset('public/frontend/media')}}/footer/3.jpg"><img style="height: 200px; width:210px" src="{{asset('public/frontend/media')}}/footer/3.jpg"alt=""></a>

                    <a href="{{asset('public/frontend/media')}}/footer/5.jpg"><img style="height: 200px; width:210px" src="{{asset('public/frontend/media')}}/footer/5.jpg"alt=""></a>

                    <a href="{{asset('public/frontend/media')}}/footer/5.jpg"><img style="height: 200px; width:210px" src="{{asset('public/frontend/media')}}/footer/5.jpg"alt=""></a>
             
                    
                </div>
            </aside>
        </div>

    </div>

</div>

    
@endsection