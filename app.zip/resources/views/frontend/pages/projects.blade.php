@extends('frontend.master')

@section('content')
@include('frontend.layouts.pageBanner')

<section id="project_list">
    <div class="container">
        
        <ul class="portfolioFilter text-center wow animated fadeInUp" data-wow-delay="0ms"
            data-wow-duration="1500ms">
            <li><a href="#0" class="filter current" data-filter=".mix">All</a></li>
            <li><a href="#0" class="filter" data-filter=".design">Building</a></li>
            <li><a href="#0" class="filter" data-filter=".development">Flyover</a></li>
            <li><a href="#0" class="filter" data-filter=".branding">Bridge</a></li>
        </ul>
        <div class="portfolio_container row animated fadeInUp" data-wow-delay="300ms"
            data-wow-duration="1500ms">
            <div class="col-md-4 col-xs-6 mix full-width design">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width design">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width branding">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="{{route('projectDetails')}}"><img src="{{asset('public/frontend/media')}}/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="{{route('projectDetails')}}" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- <div class="col-sm-12">
            <ul class="portfolio-nav text-center wow animated fadeInUp" data-wow-delay="0ms"
                data-wow-duration="1500ms">
                <li><a href="{{route('projectDetails')}}"><i class="fa fa-angle-left"></i></a></li>
                <li class="page-active"><a href="{{route('projectDetails')}}">1</a></li>
                <li><a href="{{route('projectDetails')}}">2</a></li>
                <li><a href="{{route('projectDetails')}}">3</a></li>
                <li><a href="{{route('projectDetails')}}"><i class="fa fa-angle-right"></i></a></li>
            </ul>
        </div> --}}
    </div>
</section>
    

@include('frontend.layouts.banner')
@endsection