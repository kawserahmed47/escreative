<aside class="widget widget_archive">
    <h3 class="widget-title">Gallery</h3>
    <div class="gallery">
        
        <a href="{{asset('public/frontend/media')}}/recent-work/recent-work-4.jpg">
        <img style="height:100px; width:100px" src="{{asset('public/frontend/media')}}/recent-work/recent-work-4.jpg"alt="">
        </a>
                
        <a href="{{asset('public/frontend/media')}}/recent-work/recent-work-5.jpg">
        <img style="height:100px; width:100px" src="{{asset('public/frontend/media')}}/recent-work/recent-work-5.jpg" alt="">
        </a>
        
        <a href="{{asset('public/frontend/media')}}/recent-work/recent-work-3.jpg">
        <img style="height:100px; width:100px" src="{{asset('public/frontend/media')}}/recent-work/recent-work-3.jpg" alt="">
        </a>
        
        <a href="{{asset('public/frontend/media')}}/recent-work/recent-work-1.JPG">
        <img style="height:100px; width:100px" src="{{asset('public/frontend/media')}}/recent-work/recent-work-1.JPG" alt="">
        </a>
    </div>
</aside>