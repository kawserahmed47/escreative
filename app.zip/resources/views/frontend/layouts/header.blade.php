<section class="top_menu">
    <div class="top-bg clearfix">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p style="color:white"> <strong>人と街にやさしい住まいを 住宅リフォーム・メンテナンス</strong></p>
                </div>
                <div class="col-md-6">
                    <div class="text-right">
                        <ul class="site-social-link">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                        </ul>
                        {{-- <select>
                            <option value="">EN</option>
                            <option value="">JP</option>
                        </select> --}}
                    </div>
                  
                </div>
            </div>
        </div>
       

    </div>



    <div class="top-contact">
        <div class="">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                <div class="dt-site-logo text-center mb-3"><a href="{{route('index')}}" class="main-logo"><img
                                src="{{asset('public/frontend')}}/assets/img/logo-main-lg.png" alt=""></a></div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="contact-details"><span><i class="fa fa-paper-plane"></i></span>
                            <p>Email Us</p>
                            <p class="con-text"><a href="mailto:es_creative@yahoo.com">es_creative@yahoo.com</a></p>
                        </div>
                        <div class="contact-details"><span><i class="fa fa-phone"></i></span>
                            <p>Call Now</p>
                            <p></p>
                            <p class="con-text"><a href="tel:048-940-3935">048-940-3935</a></p>
                        </div>
                        <div class="contact-details"><span><i class="fa fa-map-marker"></i></span>
                            <p>Find Us</p>
                            <div style="width: 75%;margin-left: 35px">
                                <img src="{{asset('public/frontend')}}/assets/img/address.JPG" alt="">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br><br>

<header id="header_menu">
    <div class="">
        <div class="header-logo"><img src="{{asset('public/frontend')}}/assets/img/eslogo.png" alt="logo"></div>
        <nav class="menu menu--juno" style="margin-top:15px">
            <ul class="menu__list">
            <li class="menu__item menu__item--current"><a href="{{route('index')}}" class="menu__link"><h4>Home</h4></a></li>
            <li class="menu__item"><a href="{{route('about')}}" class="menu__link"><h4>About <i class="fa fa-caret-down" aria-hidden="true"></i></h4></a>
                    <ul class="child-menu">
                        <li><a href="{{route('about')}}">About Us</a></li>
                        <li><a href="{{route('ceoMessage')}}">Message of CEO</a></li>
                        <li><a href="{{route('profile')}}">Profile</a></li>
                        <li><a href="{{route('team')}}">Team Introduction</a></li>
                        <li><a href="{{route('mission')}}">Our Mission</a></li>
                        <li><a href="{{route('vision')}}">Our Vision</a></li>
                        <li><a href="{{route('history')}}">History</a></li>
                        <li><a href="{{route('gallery')}}">Gallery</a></li>
                        <li><a href="{{route('faq')}}">FAQ</a></li>
                    </ul>
                </li>
                <li class="menu__item"><a href="{{route('services')}}" class="menu__link"><h4>Services <i class="fa fa-caret-down" aria-hidden="true"></i> </h4></a>
                    <ul class="child-menu">
                        <li><a href="{{route('serviceDetails')}}">住宅リフォームの施工・管理</a></li>
                        <li><a href="{{route('serviceDetails')}}">リフォーム後のメンテナンス</a></li>
                        <li><a href="{{route('serviceDetails')}}">内装工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">防犯工事</a></li>
                        <li><a href="{{route('serviceDetails')}}"> 外装工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}">防火工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}"> 付帯設備工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">■ 耐震補強</a></li>
                    </ul>
                </li>
            <li class="menu__item"><a href="{{route('projects')}}" class="menu__link"><h4>Projects</h4></a></li>
            <li class="menu__item"><a href="{{route('products')}}" class="menu__link"><h4>Products</h4></a></li>
            <li class="menu__item"><a href="{{route('news')}}" class="menu__link"><h4>News</h4></a></li>
            <li class="menu__item"><a href="{{route('contact')}}" class="menu__link"><h4>Contact Us</h4></a></li>
            </ul>
        </nav> 
    </div>
</header>

<div id="mobile-header"><a class="main-logo" href="{{route('index')}}"><img src="{{asset('public/frontend')}}/assets/img/eslogo_mobile.png" alt=""></a>
    <div class="menu-container">
        <div class="menu-toggle toggle-menu menu-right push-body">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>



<div id="mobile-wrapper" class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right">
    <div class="mobile-menu-container">
     
        <nav id="accordian">
            <ul class="accordion-menu">
                <li class="single-link"><a href="{{route('index')}}">Home</a></li>
                  <li><a href="#0" class="dropdownlink">About Us <i class="fa fa-chevron-down"
                            aria-hidden="true"></i></a>
                    <ul class="submenuItems">
                        <li><a href="{{route('about')}}">About Us</a></li>
                        <li><a href="{{route('ceoMessage')}}">Message of CEO</a></li>
                        <li><a href="{{route('profile')}}">Profile</a></li>
                        <li><a href="{{route('team')}}">Team Introduction</a></li>
                        <li><a href="{{route('mission')}}">Our Mission</a></li>
                        <li><a href="{{route('vision')}}">Our Vision</a></li>
                        <li><a href="{{route('history')}}">History</a></li>
                        <li><a href="{{route('gallery')}}">Gallery</a></li>
                        <li><a href="{{route('faq')}}">FAQ</a></li>
                    </ul>
                </li>
                 <li><a href="#0" class="dropdownlink">Services <i class="fa fa-chevron-down"
                            aria-hidden="true"></i></a>
                    <ul class="submenuItems">
                       <li><a href="{{route('serviceDetails')}}">住宅リフォームの施工・管理</a></li>
                        <li><a href="{{route('serviceDetails')}}">リフォーム後のメンテナンス</a></li>
                        <li><a href="{{route('serviceDetails')}}">内装工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">防犯工事</a></li>
                        <li><a href="{{route('serviceDetails')}}"> 外装工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}">防火工事 </a></li>
                        <li><a href="{{route('serviceDetails')}}"> 付帯設備工事</a></li>
                        <li><a href="{{route('serviceDetails')}}">■ 耐震補強</a></li>
                    </ul>
                </li>
                <li class="single-link"><a href="{{route('projects')}}">Projects</a></li>
                <li class="single-link"><a href="{{route('products')}}">Products</a></li>
                <li class="single-link"><a href="{{route('news')}}">News</a></li>
                  <li class="single-link"><a href="{{route('contact')}}">Contact Us</a></li>
            </ul>
        </nav>
    </div>
</div>
