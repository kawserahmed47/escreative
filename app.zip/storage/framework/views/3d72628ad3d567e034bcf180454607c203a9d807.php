

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="service_single">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <aside class="service-widgets">
                    <h3 class="widget-title">What We Do?</h3>
                    <ul class="servile-link">
                        <li><a href="#">Building Creation <i class="fa fa-angle-right"></i></a></li>
                        <li><a href="#">Bridge Creation <i class="fa fa-angle-right"></i></a></li>
                        <li><a href="#">Factory Building <i class="fa fa-angle-right"></i></a></li>
                        <li><a href="#">Flyover Creation <i class="fa fa-angle-right"></i></a></li>
                        <li><a href="#">Small Home <i class="fa fa-angle-right"></i></a></li>
                    </ul>
                </aside>
                
                    <?php echo $__env->make('frontend.layouts.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <div class="service-single">
                    <div class="service-thumb"><img src="<?php echo e(asset('public/frontend/media')); ?>/service/5.jpg" alt="Service"></div>
                    <div class="service-content">
                        <h2>Bridge Creation service</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error
                            sit voluptatem accusantium doloremque</p>
                        <p>laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
                            architecto beatae vitae dicta sunt explicabo. in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                            culpa qui officia</p>
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-cup"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-gear"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-globe"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-home"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-pencil-ruler"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="service-feature">
                                <div class="icon"><i class="icon dti-settings"></i></div>
                                <div class="content">
                                    <h4>Great Feature</h4>
                                    <p>Lorem ipsm dolor sit consectetur adipiscing elit. Suspendisse for a
                                        viverra mauris eget tortor</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 text-center"><a href="#" class="dt-btn"><i
                                    class="fa fa-cloud-download"></i> Download Brochure</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/escreati/public_html/resources/views/frontend/pages/serviceDetails.blade.php ENDPATH**/ ?>