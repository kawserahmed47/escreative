
<section id="popular-service">
    <div class="container">
        <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Popular Service</h2>
        <p class="sub-title wow animated fadeInUp" data-wow-delay="200ms">Here is show our popular service for
            our clients, who want to create<br>building from us, and who have huge money for spend.</p>
        <div class="row wow animated fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">

            <div class="col-md-3 col-sm-6 mb-2">
            <div class="pop-service"> <a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-1.jfif" alt="service"></a> 
                    <div class="service-details">
                        <p>住宅リフォームの施工・管理</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-2.jpg" alt="service"></a>
                    <div class="service-details">
                        <p>リフォーム後のメンテナンス</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-4.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>内装工事</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-5.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>防犯工事</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-6.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>外装工事</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-8.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>防火工事</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-9.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>付帯設備工事</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><a href="<?php echo e(route('serviceDetails')); ?>"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/service/service-10.jfif" alt="service"></a>
                    <div class="service-details">
                        <p>■ 耐震補強</p>
                        
                    </div>
                </div>
            </div>

        </div>
    </div>
</section><?php /**PATH /home/escreati/public_html/resources/views/frontend/layouts/services.blade.php ENDPATH**/ ?>