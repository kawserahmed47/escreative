<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
<section id="blog_list">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="blog-post wow animated fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="blog-thumb"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/4.jpg" alt="Blog Thumb"></div>
                    <div class="blog-content">
                        <h3 class="blog-title"><a href="#">We’d like to introduce our new mobile app, that makes
                                your life much easier.</a></h3>
                        <ul class="post-meta">
                            <li><a href="#"><i class="fa fa-user"></i>Johnny Cage</a></li>
                            <li><a href="#"><i class="fa fa-folder-o"></i>User Interface</a></li>
                            <li><a href="#"><i class="fa fa-calendar"></i>22 Sept 2016</a></li>
                            <li><a href="#"><i class="fa fa-comments-o"></i>11 Comments</a></li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur.</p><a href="#" class="dt-btn">Read More</a>
                    </div>
                </div>
                <div class="blog-post wow animated fadeInUp" data-wow-delay="100ms" data-wow-duration="1500ms">
                    <div class="blog-thumb"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/5.jpg" alt="Blog Thumb"></div>
                    <div class="blog-content">
                        <h3 class="blog-title"><a href="#">We’d like to introduce our new mobile app, that makes
                                your life much easier.</a></h3>
                        <ul class="post-meta">
                            <li><a href="#"><i class="fa fa-user"></i>Johnny Cage</a></li>
                            <li><a href="#"><i class="fa fa-folder-o"></i>User Interface</a></li>
                            <li><a href="#"><i class="fa fa-calendar"></i>22 Sept 2016</a></li>
                            <li><a href="#"><i class="fa fa-comments-o"></i>11 Comments</a></li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur.</p><a href="#" class="dt-btn">Read More</a>
                    </div>
                </div>
                <div class="blog-post wow animated fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                    <div class="blog-thumb"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/6.jpg" alt="Blog Thumb"></div>
                    <div class="blog-content">
                        <h3 class="blog-title"><a href="#">We’d like to introduce our new mobile app, that makes
                                your life much easier.</a></h3>
                        <ul class="post-meta">
                            <li><a href="#"><i class="fa fa-user"></i>Johnny Cage</a></li>
                            <li><a href="#"><i class="fa fa-folder-o"></i>User Interface</a></li>
                            <li><a href="#"><i class="fa fa-calendar"></i>22 Sept 2016</a></li>
                            <li><a href="#"><i class="fa fa-comments-o"></i>11 Comments</a></li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur.</p><a href="#" class="dt-btn">Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <aside id="nav_menu-2" class="widget widget_nav_menu">
                    <h3 class="widget-title">Categories</h3>
                    <ul class="dt_custom_menu">
                        <li><a href="#"><i class="icon dti-message-text"></i>Latest News <sup>6</sup></a></li>
                        <li><a href="#"><i class="icon dti-todolist-pencil"></i>Finance <sup>12</sup></a></li>
                        <li><a href="#"><i class="icon dti-hammer"></i>Investment <sup>17</sup></a></li>
                        <li><a href="#"><i class="icon dti-clessidre"></i>Mission <sup>13</sup></a></li>
                        <li><a href="#"><i class="icon dti-diamond"></i>Financing Loan <sup>19</sup></a></li>
                    </ul>
                </aside>
                <aside class="widget widget_recent_entries">
                    <h3 class="widget-title">Recent Posts</h3>
                    <div class="resent-post">
                        <div class="post-thumbs"><a href="#"><img class="media-object" src="<?php echo e(asset('public/frontend/media')); ?>/blog/7.jpg"
                                    alt="01"></a></div>
                        <div class="post-content">
                            <h5><a href="#">Makes your life easier</a></h5><a href="#">16 Feb 2017</a>
                            <p>Lorem ipsum dolor sit consecte imperdiet iaculis ipsum...</p>
                        </div>
                    </div>
                    <div class="resent-post">
                        <div class="post-thumbs"><a href="#"><img class="media-object" src="<?php echo e(asset('public/frontend/media')); ?>/blog/8.jpg"
                                    alt="01"></a></div>
                        <div class="post-content">
                            <h5><a href="#">Makes your life easier</a></h5><a href="#">13 Feb 2017</a>
                            <p>Lorem ipsum dolor sit consecte imperdiet iaculis ipsum...</p>
                        </div>
                    </div>
                    <div class="resent-post">
                        <div class="post-thumbs"><a href="#"><img class="media-object" src="<?php echo e(asset('public/frontend/media')); ?>/blog/9.jpg"
                                    alt="01"></a></div>
                        <div class="post-content">
                            <h5><a href="#">Makes your life easier</a></h5><a href="#">16 Jan 2011</a>
                            <p>Lorem ipsum dolor sit consecte imperdiet iaculis ipsum...</p>
                        </div>
                    </div>
                </aside>
                
                <aside class="widget widget_archive">
                    <h3 class="widget-title">Gallery</h3>
                    <div class="gallery"><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/2.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/1.png"
                                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/2.png"
                                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/4.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/3.png"
                                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/4.png"
                                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/6.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/5.png"
                                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/8.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/6.png"
                                alt=""></a></div>
                </aside>
               
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/news.blade.php ENDPATH**/ ?>