

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-md-2">

        </div>

        <div class="col-md-8">
            <div class="contact">
                <h2 class="contact-title">Get Quotation</h2>
                <p>If you want to quotation, please see our address or call our number or send us
                    on our email, we will contact with you for our own business, so don’t worrie we are
                    beside you to help you.</p>
                <form action="" id="" method="post">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="name-field"><input
                                    class="form-control contact-form-field cffield-upper" name="fname"
                                    id="form-name" placeholder="Name" type="text" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="email-field"><input
                                    class="form-control contact-form-field cffield-upper" name="femail"
                                    id="form-email" placeholder="Email" type="email" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="name-field"><input
                                    class="form-control contact-form-field cffield-upper" name="fname"
                                    id="form-name" placeholder="Mobile" type="text" required=""></div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group" id="email-field"><input
                                    class="form-control contact-form-field cffield-upper" name="femail"
                                    id="form-email" placeholder="Address" type="text" required=""></div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group" id="subject-field"><input
                                    class="form-control contact-form-field cffield-upper"
                                    name="fsubject" id="form-subject" placeholder="Types of Query" type="text"
                                    required=""></div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group form-text text-center" id="message-field"><textarea
                                    cols="30" rows="6" placeholder="Your Query"
                                    class="form-control contact-form-field" name="fmessage"
                                    id="form-message" required=""></textarea>
                                
                            </div>
                        </div>
                        <div class="col-md-12"><button class="dt-btn" type="submit">Send</button></div>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-2">

        </div>

    </div>

</div>
<br><br>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/escreati/public_html/resources/views/frontend/pages/quotation.blade.php ENDPATH**/ ?>