<aside class="widget widget_archive">
    <h3 class="widget-title">Gallery</h3>
    <div class="gallery"><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/2.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/1.png"
                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/2.png"
                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/4.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/3.png"
                alt=""></a><a href="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"><img src="<?php echo e(asset('public/frontend/media')); ?>/footer/4.png"
                alt=""></a></div>
</aside><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/layouts/gallery.blade.php ENDPATH**/ ?>