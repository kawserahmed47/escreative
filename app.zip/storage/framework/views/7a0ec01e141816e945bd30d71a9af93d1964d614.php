<section id="choice">
    <div class="container">
        <div class="choice clearfix">
            <h4>Are You Want a Awesome Construction Agency?</h4>
        <h2>We are the right choice for your project you know.</h2><a href="<?php echo e(route('quotation')); ?>" class="dt-btn">Get Quotation</a>
        </div>
    </div>
</section><?php /**PATH /home/escreati/public_html/resources/views/frontend/layouts/banner.blade.php ENDPATH**/ ?>