<section class="top_menu">
    <div class="top-bg clearfix">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p style="color:white"> <strong>人と街にやさしい住まいを 住宅リフォーム・メンテナンス</strong></p>
                </div>
                <div class="col-md-6">
                    <div class="text-right">
                        <ul class="site-social-link">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                        </ul>
                        
                    </div>
                  
                </div>
            </div>
        </div>
       

    </div>



    <div class="top-contact">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                <div class="dt-site-logo text-center"><a href="<?php echo e(route('index')); ?>" class="main-logo"><img
                                src="<?php echo e(asset('public/frontend')); ?>/assets/img/eslogo.png" alt=""></a></div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="contact-details"><span><i class="fa fa-paper-plane"></i></span>
                            <p>Email Us</p>
                            <p class="con-text"><a href="mailto:es_creative@yahoo.com">es_creative@yahoo.com</a></p>
                        </div>
                        <div class="contact-details"><span><i class="fa fa-phone"></i></span>
                            <p>Call Now</p>
                            <p></p>
                            <p class="con-text"><a href="tel:048-940-3935">048-940-3935</a></p>
                        </div>
                        <div class="contact-details mb-3"><span><i class="fa fa-map-marker"></i></span>
                            <p>Find Us</p>
                            <p class="con-text">【本社】〒343-0035 埼玉県越谷市大字大道 510 番地 1 階</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br><br>

<header id="header_menu">
    <div class="container">
        <div class="header-logo"><img src="<?php echo e(asset('public/frontend')); ?>/assets/img/eslogo.png" alt="logo"></div>
        <nav class="menu menu--juno">
            <ul class="menu__list">
            <li class="menu__item menu__item--current"><a href="<?php echo e(route('index')); ?>" class="menu__link">Home</a></li>
            <li class="menu__item"><a href="<?php echo e(route('about')); ?>" class="menu__link">About <i class="fa fa-caret-down" aria-hidden="true"></i> </a>
                    <ul class="child-menu">
                        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('ceoMessage')); ?>">Message of CEO</a></li>
                        <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
                        <li><a href="<?php echo e(route('team')); ?>">Team Introduction</a></li>
                        <li><a href="<?php echo e(route('mission')); ?>">Our Mission</a></li>
                        <li><a href="<?php echo e(route('vision')); ?>">Our Vision</a></li>
                        <li><a href="<?php echo e(route('history')); ?>">History</a></li>
                        <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                        <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                    </ul>
                </li>
                <li class="menu__item"><a href="<?php echo e(route('services')); ?>" class="menu__link">Services <i class="fa fa-caret-down" aria-hidden="true"></i> </a>
                    <ul class="child-menu">
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">住宅リフォームの施工・管理</a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">リフォーム後のメンテナンス</a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">内装工事</a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">防犯工事</a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>"> 外装工事 </a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">防火工事 </a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>"> 付帯設備工事</a></li>
                        <li><a href="<?php echo e(route('serviceDetails')); ?>">■ 耐震補強</a></li>
                    </ul>
                </li>
            <li class="menu__item"><a href="<?php echo e(route('projects')); ?>" class="menu__link">Projects</a></li>
            <li class="menu__item"><a href="<?php echo e(route('products')); ?>" class="menu__link">Products/Shop</a></li>
            <li class="menu__item"><a href="<?php echo e(route('news')); ?>" class="menu__link">News / Event</a></li>
            <li class="menu__item"><a href="<?php echo e(route('contact')); ?>" class="menu__link">Contact Us</a></li>
            </ul>
        </nav>
    </div>
</header>

<div id="mobile-header"><a class="main-logo" href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('public/frontend')); ?>/assets/img/logo.png" alt=""></a>
    <div class="menu-container">
        <div class="menu-toggle toggle-menu menu-right push-body">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>



<div id="mobile-wrapper" class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right">
    <div class="mobile-menu-container">
        <div id="mobile_menu_search">
            <div id="search">
                <form method="get" action="#"><input type="text" name="s" placeholder="Search" class="search"
                        value=""> <button type="submit" id="searchsubmit" value=""><i
                            class="fa fa-search"></i></button></form>
            </div>
        </div>
        <hr>
        <nav id="accordian">
            <ul class="accordion-menu">
                <li class="single-link"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="single-link"><a href="about.html">About Us</a></li>
                <li class="single-link"><a href="about.html">Services</a></li>
                <li class="single-link"><a href="about.html">Products</a></li>
                <li class="single-link"><a href="about.html">Projects</a></li>
                <li><a href="#0" class="dropdownlink">Blog <i class="fa fa-chevron-down"
                            aria-hidden="true"></i></a>
                    <ul class="submenuItems">
                        <li><a href="blog-list.html">Blog List</a></li>
                        <li><a href="blog-single.html">Blog Single</a></li>
                    </ul>
                </li>
                <li class="single-link"><a href="contact.html">Contact</a></li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>