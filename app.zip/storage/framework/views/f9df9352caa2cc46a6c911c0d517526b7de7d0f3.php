<section id="page-banner" data-bg-image="media/banner/5.jpg" data-parallax="image">
    <div class="overlay"></div>
    <div class="container text-center">
        <div class="banner-content">
            <h2 class="page-title"><?php if($title): ?><?php echo e($title); ?><?php endif; ?></h2>
            <h5 class="text-light">Home / <?php if($title): ?><?php echo e($title); ?><?php endif; ?></h5>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/layouts/pageBanner.blade.php ENDPATH**/ ?>