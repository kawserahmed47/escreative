<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        
<section id="contact">
    <div class="container">
        <div class="contact-area">
            <div class="row">
                <div class="col-md-8">
                    <div class="contact">
                        <h2 class="contact-title">Contact Us</h2>
                        <p>If you want to connect with me, please see our address or call our number or mail us
                            on our email, we will contact with you for our own business, so don’t worrie we are
                            beside you to help you.</p>
                        <form action="" id="" method="post">
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group" id="name-field"><input
                                            class="form-control contact-form-field cffield-upper" name="fname"
                                            id="form-name" placeholder="Name" type="text" required=""></div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group" id="email-field"><input
                                            class="form-control contact-form-field cffield-upper" name="femail"
                                            id="form-email" placeholder="Email" type="email" required=""></div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group" id="subject-field"><input
                                            class="form-control contact-form-field cffield-upper"
                                            name="fsubject" id="form-subject" placeholder="Subject" type="text"
                                            required=""></div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group form-text text-center" id="message-field"><textarea
                                            cols="30" rows="6" placeholder="Your message"
                                            class="form-control contact-form-field" name="fmessage"
                                            id="form-message" required=""></textarea>
                                        <grammarly-btn>
                                            <div style="visibility: hidden; z-index: 2"
                                                class="_e725ae-textarea_btn _e725ae-not_focused"
                                                data-grammarly-reactid=".0">
                                                <div class="_e725ae-transform_wrap"
                                                    data-grammarly-reactid=".0.0">
                                                    <div title="Protected by Grammarly" class="_e725ae-status"
                                                        data-grammarly-reactid=".0.0.0">&nbsp;</div>
                                                </div>
                                            </div>
                                        </grammarly-btn>
                                    </div>
                                </div>
                                <div class="col-md-12"><button class="dt-btn" type="submit">Send</button></div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-address">
                        <div class="address">
                            <div class="con-icon"><i class="fa fa-home"></i></div>
                            <h5>【本社】</h5>
                            <p>〒343-0035 埼玉県越谷市大字大道 510 番地 1 階</p>
                        </div>
                        <div class="address">
                            <div class="con-icon"><i class="fa fa-envelope-o"></i></div>
                            <h5>Email Address</h5>
                            <p> <a href="mailto:es_creative@yahoo.com">es_creative@yahoo.com</a></p>
                        </div>
                        <div class="address">
                            <div class="con-icon"><i class="fa fa-phone"></i></div>
                            <h5>Contact Number</h5>
                            <p><a href="tel:048-940-3935">048-940-3935</a></p>
                        </div>
                        <div class="open">
                            <h3 class="contact-title">Opening Hours</h3>
                            <p>Sat - Thu......8:00am - 05:00pm</p>
                            <p class="text-dark">Offday: Friday</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="google-map">
        <div class="show-map">
            <div class="gmap3-area" data-lat="23.733248" data-lng="90.412040"
                data-mrkr="assets/img/map-marker.png"></div>
        </div>
    </div>
</section>

<?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>