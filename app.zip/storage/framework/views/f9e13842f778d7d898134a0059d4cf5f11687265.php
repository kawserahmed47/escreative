<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer-ab">
                    <div class="footer-logo"><a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/assets/img/eslogo.png" alt="logo"></a>
                    </div>
                    <p>We are the boss of the constract so be care full to talk us, we are build</p>
                    <p>tajmahal, white house, you already gueeas who am.</p>
                    <ul class="social-link">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="usefull-link">
                    <h5 class="footer-title">Usefull Link</h5>
                    <ul class="footer-link">
                    <li><a href="<?php echo e(route('about')); ?>"><i class="fa fa-angle-right"></i>About US</a></li>
                    <li><a href="<?php echo e(route('services')); ?>"><i class="fa fa-angle-right"></i>Services</a></li>
                    <li><a href="<?php echo e(route('projects')); ?>"><i class="fa fa-angle-right"></i>Projects</a></li>
                    <li><a href="<?php echo e(route('products')); ?>"><i class="fa fa-angle-right"></i>Products</a></li>
                    <li><a href="<?php echo e(route('team')); ?>"><i class="fa fa-angle-right"></i>Team</a></li>
                    <li><a href="<?php echo e(route('faq')); ?>"><i class="fa fa-angle-right"></i>FAQ</a></li> 
                    <li><a href="<?php echo e(route('contact')); ?>"><i class="fa fa-angle-right"></i>Contact</a></li>
                    <li><a href="<?php echo e(route('quotation')); ?>"><i class="fa fa-angle-right"></i>Quotation</a></li>
                     
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer-contact">
                    <h5 class="footer-title">Contact</h5>
                    <div class="contact-details clearfix"><span><i class="fa fa-paper-plane"></i></span>
                        <p>Email Us</p>
                        <p class="con-text"><a href="mailto:es_creative@yahoo.com">es_creative@yahoo.com</a></p>
                    </div>
                    <div class="contact-details clearfix"><span><i class="fa fa-phone"></i></span>
                        <p>Call Now</p>
                        <p></p>
                        <p class="con-text"><a href="tel:048-940-3935">048-940-3935</a></p>
                    </div>
                    <div class="contact-details clearfix"><span><i class="fa fa-map-marker"></i></span>
                        <p>Find Us</p>
                        <p class="con-text">【本社】〒343-0035 埼玉県越谷市大字大道 510 番地 1 階</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <h5 class="footer-title">Gallery</h5>
                 <?php echo $__env->make('frontend.layouts.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               
                <!--<div class="footer-gallery">-->
                <!--    <h5 class="footer-title">Recent Gallery</h5>-->
                <!--    <a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/footer/1.png"alt=""></a>-->
                <!--    <a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/footer/2.png" alt=""></a>-->
                <!--    <a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/footer/3.png" alt=""></a>-->
                <!--    <a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/footer/4.png" alt=""></a>-->
                <!--    -->
                <!--</div>-->
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>Copyright 2020. All right reserved by ES Creative Industries Co. Ltd.</p>
    </div>
</footer><?php /**PATH /home/escreati/public_html/resources/views/frontend/layouts/footer.blade.php ENDPATH**/ ?>