<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br><br>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo e(asset('public/frontend/media/resource/vision.jpg')); ?>" alt="Mission Preview">


            </div>
            <div class="col-md-6">
                <h3 class="p-3">Vision</h3>
                <hr>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius obcaecati odio doloremque repellat numquam, cum esse fuga exercitationem temporibus amet nemo unde itaque et recusandae nostrum ipsum blanditiis, porro facere?</p>
            </div>

            

        </div>
    </div>
</section>
<br><br>
<?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/vision.blade.php ENDPATH**/ ?>