<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="project_list">
    <div class="container">
        
        <ul class="portfolioFilter text-center wow animated fadeInUp" data-wow-delay="0ms"
            data-wow-duration="1500ms">
            <li><a href="#0" class="filter current" data-filter=".mix">All</a></li>
            <li><a href="#0" class="filter" data-filter=".design">Building</a></li>
            <li><a href="#0" class="filter" data-filter=".development">Flyover</a></li>
            <li><a href="#0" class="filter" data-filter=".branding">Bridge</a></li>
        </ul>
        <div class="portfolio_container row animated fadeInUp" data-wow-delay="300ms"
            data-wow-duration="1500ms">
            <div class="col-md-4 col-xs-6 mix full-width design">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width design">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width development">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-6 mix full-width branding">
                <div class="portfolio-item">
                    <div class="blog-grid">
                        <div class="blog-thumb"><a href="<?php echo e(route('projectDetails')); ?>"><img src="<?php echo e(asset('public/frontend/media')); ?>/blog/1.jpg" alt="blog thumb"></a>
                        </div>
                        <div class="blog-content">
                            <h3 class="blog-title">Building Create project in dubai.</h3>
                            <p>At first you need a pencil and artboard then you need a parsonal assistent then
                                you need sketch your whole plane, when complete your sketch please rivision it
                                agein.</p><a href="<?php echo e(route('projectDetails')); ?>" class="dt-btn">More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</section>
    

<?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/projects.blade.php ENDPATH**/ ?>