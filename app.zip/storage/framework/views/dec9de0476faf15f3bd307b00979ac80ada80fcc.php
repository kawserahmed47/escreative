<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
    <div class="row">
        <div class="col">
            <aside class="widget widget_archive">
              
                <div class="gallery">
                    <a href="<?php echo e(asset('public/frontend/media')); ?>/footer/2.jpg"><img style="height: 200px; width:210px" src="<?php echo e(asset('public/frontend/media')); ?>/footer/2.jpg" alt=""></a>

                    <a href="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg"><img style="height: 200px; width:210px" src="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg" alt=""></a>

                    <a href="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg"><img style="height: 200px; width:210px" src="<?php echo e(asset('public/frontend/media')); ?>/footer/3.jpg"alt=""></a>

                    <a href="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"><img style="height: 200px; width:210px" src="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"alt=""></a>

                    <a href="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"><img style="height: 200px; width:210px" src="<?php echo e(asset('public/frontend/media')); ?>/footer/5.jpg"alt=""></a>
             
                    
                </div>
            </aside>
        </div>

    </div>

</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/gallery.blade.php ENDPATH**/ ?>