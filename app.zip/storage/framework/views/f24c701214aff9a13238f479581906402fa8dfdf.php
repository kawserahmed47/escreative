<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="ab-content">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="ab-thumb wow animated fadeInRight" data-wow-delay="300ms"
                    data-wow-duration="1500ms"><img src="<?php echo e(asset('public/frontend')); ?>/media/about/7.png" alt="about"></div>
            </div>
            <div class="col-md-6">
                <div class="ab-content wow animated fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <h2 class="section-title">人と街にやさしい住まいを </h2>

                    <h5>わたしたちは、みなさまが安全で快適に過ごせる、 環境にやさしい住まいづくりを目指しています。
                    </h5>
                    <p>
                        わたしたちは、お客様のご意見を参考に、お客様のご予算に合わせ、ライフプランを 考慮した付加価値の高い提案を行い、1つ上のリフォームを実現いたします。 そして、環境にやさしく安心・安全で快適に過ごせる住まいづくりを目指しています。 わたしたちのリフォームは、お客様にご満足いただけるような空間づくりを旨とし、 よりよいライフスタイルを築く機会になることを目標にしています。 そして、お客様と長くお付き合いできるようにきめ細かいメンテナンスを行い、コミ ュニケーションを取りながら、よりよい仕事をしていきたいという想いで、スタッフ 一同、懸命に対応させていただきます。どうぞよろしくお願いいたします。

                    </p>
                    <P class="text-right">ES Creative 工業株式会社 <br> 代表取締役社長　高橋　忍</P>
                 
                </div>
            </div>
          
        </div>
    </div>
</section>

    <?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/ceoMessage.blade.php ENDPATH**/ ?>