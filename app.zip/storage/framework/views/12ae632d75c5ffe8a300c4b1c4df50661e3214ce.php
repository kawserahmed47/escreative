<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.pageBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="pricing">
    <div class="container">
        <h2 class="section-title text-center">Awesome products for you</h2>
        <p class="sub-title">Here is our pricing list by project categories, choose the best packege which
            is<br>you need, and we are commited you will won finally .</p>
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="pricing text-center">
                    <div class="pricing-head"><img src="<?php echo e(asset('public/frontend/media')); ?>/pricing/1.jpg" alt="price">
                        
                    </div>
                    <h5>Product Name</h5>
                    <ul class="plan">
                        <p>Short description</p>
                        
                    </ul><a type="button" data-toggle="modal" data-target="#exampleModal" class="dt-btn text-center">Get It</a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="pricing text-center">
                    <div class="pricing-head"><img src="<?php echo e(asset('public/frontend/media')); ?>/pricing/2.jpg" alt="price">
                        
                    </div>
                    <h5>Product Name</h5>
                    <ul class="plan">
                        <p>Short Description</p>
                        
                    </ul><a type="button" data-toggle="modal" data-target="#exampleModal" class="dt-btn text-center">Get It</a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="pricing text-center">
                    <div class="pricing-head"><img src="<?php echo e(asset('public/frontend/media')); ?>/pricing/3.jpg" alt="price">
                        
                    </div>
                    <h5>Product Name</h5>
                    <ul class="plan">
                        <p>Short Description</p>
                        
                    </ul><a type="button" data-toggle="modal" data-target="#exampleModal" class="dt-btn text-center">Get It</a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="pricing text-center">
                    <div class="pricing-head"><img src="<?php echo e(asset('public/frontend/media')); ?>/pricing/4.jpg" alt="price">
                        
                    </div>
                    <h5>Product Name</h5>
                    <ul class="plan">
                        <p>Short Description</p>
                        
                    </ul><a  type="button" class="dt-btn text-center" data-toggle="modal" data-target="#exampleModal">Get It</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div class="modal fade" style="margin-top:50px " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Product Name</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="" method="POST">
                <input type="text" class="form-control" name="" placeholder="Name" id=""><br>
                <input type="text"  class="form-control" name="" placeholder="Address" id=""><br>
                <input type="text"  class="form-control" name="" placeholder="Email" id=""><br>
                <input type="text"  class="form-control" name="" placeholder="Mobile" id=""><br>
            </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Order Now</button>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/products.blade.php ENDPATH**/ ?>