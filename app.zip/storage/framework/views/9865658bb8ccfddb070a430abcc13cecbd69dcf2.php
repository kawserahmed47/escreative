<?php $__env->startSection('content'); ?>

        
        <?php echo $__env->make('frontend.layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <section id="about" class="" data-bg-image="<?php echo e(asset('public/frontend')); ?>/media/about/1.jpg">
            <div class="container wow animated fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                <div class="tab">
                    <div class="row">
                        <div class="col-md-3">
                            <ul class="tabs">
                                <li><a href="#">Message Of CEO</a></li>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Why Choose Us</a></li>
                                <li><a href="#">Why We Best</a></li>
                            </ul>
                        </div>
                        <div class="col-md-9">
                            <div class="tab_content">
                                <div class="tabs_item clearfix"><img src="<?php echo e(asset('public/frontend')); ?>/media/about/7.png" alt="Choose">
                                    <div class="content">
                                        <h4>Message of CEO</h4><br>
                                        <p>わたしたちは、お客様のご意見を参考に、お客様のご予算に合わせ、ライフプランを 考慮した付加価値の高い提案を行い、1つ上のリフォームを実現いたします。 そして、環境にやさしく安心・安全で快適に過ごせる住まいづくりを目指しています。 わたしたちのリフォームは、お客様にご満足いただけるような空間づくりを旨とし、 よりよいライフスタイルを築く機会になることを目標にしています。 そして、お客様と長くお付き合いできるようにきめ細かいメンテナンスを行い、コミ ュニケーションを取りながら、よりよい仕事をしていきたいという想いで、スタッフ 一同、懸命に対応させていただきます。どうぞよろしくお願いいたします</p>
                                        <br>
                                        <p class="text-right">ES Creative 工業株式会社 <br> 代表取締役社長　高橋　忍</p>
                                      
                                    </div>
                                </div>
                                <div class="tabs_item clearfix"><img src="<?php echo e(asset('public/frontend')); ?>/media/about/4.jpg" alt="Choose">
                                    <div class="content">
                                        <h4>About Us</h4>
                                        <p>Beacuse we best any type of constraction work, painting work, repair ay work,
                                            complete building packege at minimal cost & many more</p>
                                        <ul class="list">
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We Are the best for
                                                constraction you know</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> Constraction is not only work
                                                it also passion</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We have 10000+ skilld and
                                                greatest worker</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> You can see our previous work
                                                form gallery</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="tabs_item clearfix"><img src="<?php echo e(asset('public/frontend')); ?>/media/about/5.jpg" alt="Choose">
                                    <div class="content">
                                        <h4>Why Choose Us?</h4>
                                        <p>Beacuse we best any type of constraction work, painting work, repair ay work,
                                            complete building packege at minimal cost & many more</p>
                                        <ul class="list">
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We Are the best for
                                                constraction you know</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> Constraction is not only work
                                                it also passion</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We have 10000+ skilld and
                                                greatest worker</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> You can see our previous work
                                                form gallery</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="tabs_item clearfix"><img src="<?php echo e(asset('public/frontend')); ?>/media/about/6.jpg" alt="Choose">
                                    <div class="content">
                                        <h4>Why Are We Best?</h4>
                                        <p>Beacuse we best any type of constraction work, painting work, repair ay work,
                                            complete building packege at minimal cost & many more</p>
                                        <ul class="list">
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We Are the best for
                                                constraction you know</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> Constraction is not only work
                                                it also passion</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> We have 10000+ skilld and
                                                greatest worker</li>
                                            <li><img src="<?php echo e(asset('public/frontend')); ?>/media/about/3.png" alt="icon"> You can see our previous work
                                                form gallery</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        
        <?php echo $__env->make('frontend.layouts.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





       <?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        

        
<section id="popular-service">
    <div class="container">
        <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Our Working <span class="text-dark">Process</span></h2>
        
        <div class="row wow animated fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/prosses/11.jpeg" alt="service">
                    <div class="service-details">
                        <p>Counseling</p>
                        <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/prosses/22.jpg" alt="service">
                    <div class="service-details">
                        <p>Contract</p>
                        <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/prosses/33.jpg" alt="service">
                    <div class="service-details">
                        <p>Start Work</p>
                        <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 mb-2">
                <div class="pop-service"><img style="height: 300px; width:370px" src="<?php echo e(asset('public/frontend/media')); ?>/prosses/44.jfif" alt="service">
                    <div class="service-details">
                        <p>Delivery</p>
                        <a href="#"><i class="fa fa-long-arrow-up"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
        



        
        <section id="team" data-bg-image="<?php echo e(asset('public/frontend')); ?>/media/team/1.jpg">
            <div class="container">
                <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Meet the team</h2>
                <p class="sub-title wow animated fadeInUp" data-wow-delay="200ms" data-wow-duration="1000ms">Here i show
                    our some expert and creative people.</p>
                <div class="row wow animated fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="col-md-3 col-sm-6">
                        <div class="team-member"><img class="bg-light" src="<?php echo e(asset('public/frontend')); ?>/media/team/5.png" alt="">
                            <div class="intro-member">
                                <h5>代表取締役社長　</h5>
                                <h4>高橋　忍</h4>
                                <ul class="member-profile">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="team-member"><img  class="bg-light" src="<?php echo e(asset('public/frontend')); ?>/media/team/5.png" alt="">
                            <div class="intro-member">
                                <h5>代表取締役社長　</h5>
                                <h4>高橋　忍</h4>
                                <ul class="member-profile">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="team-member"><img class="bg-light" src="<?php echo e(asset('public/frontend')); ?>/media/team/5.png" alt="">
                            <div class="intro-member">
                                <h5>代表取締役社長　</h5>
                                <h4>高橋　忍</h4>
                                <ul class="member-profile">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="team-member"><img class="bg-light" src="<?php echo e(asset('public/frontend')); ?>/media/team/5.png" alt="">
                            <div class="intro-member">
                                <h5>代表取締役社長　</h5>
                                <h4>高橋　忍</h4>
                                <ul class="member-profile">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        <section id="recent_project">
            <div class="container">
                <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Recent Project</h2>
                <p class="sub-title wow animated fadeInUp" data-wow-delay="200ms">Here i show our main services you ca
                    see this if you need, we are the boos of the constraction industry so you can order any service
                    without any hisitetion, why late</p>
                <div class="row fadeInBottom">
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/1.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/2.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/3.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="500ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/4.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="500ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/5.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wow animated fadeInUp" data-wow-delay="500ms"
                        data-wow-duration="1500ms">
                        <div class="project"><img src="<?php echo e(asset('public/frontend')); ?>/media/recent-work/6.jpg" alt="project">
                            <div class="project-intro">
                                <h3>Whitehouse Project</h3>
                                <p>This is running project of us, this place is united state, this worked is started was
                                    December 2015</p><a href="#" class="dt-btn bg-transpernt">More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        
        <section id="testimonial" data-bg-image="<?php echo e(asset('public/frontend')); ?>/media/testimonial/1.jpg" data-parallax="image" data-carousel="swiper">
            <div class="container">

                <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Testimonial</h2>

                <p class="sub-title wow animated fadeInUp text-dark " data-wow-delay="200ms">Here i show our main services you ca
                    see this if you need, we are the boos of the constraction industry so you can order any service
                    without any hisitetion, why late</p>

                <div class="testimonial-slider">
                    <div class="swiper-container" data-swiper="container" data-items="2" data-space="70"
                        data-loop="true" data-autoplay="5000" data-speed="600"
                        data-breakpoints='{"5000": {"slidesPerView": 2}, "1024": {"slidesPerView": 2}, "768": {"slidesPerView": 1}, "480": {"slidesPerView": 1}}'>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="testimonial clearfix">
                                    <div class="content">
                                        <div class="testi-thumb"><img src="<?php echo e(asset('public/frontend')); ?>/media/testimonial/3.jfif" alt="Testi"></div>
                                        <p class="text-dark">heay are provided awesome service, i am fully satisfied on those service,
                                            theay are really like a super man</p>
                                        <ul class="star">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="user-details text-right">
                                        <h3 class="name">Jone Smith</h3><span>Front End Developer</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial clearfix">
                                    <div class="content">
                                        <div class="testi-thumb"><img src="<?php echo e(asset('public/frontend')); ?>/media/testimonial/4.jpg" alt="Testi"></div>
                                        <p class="text-dark">heay are provided awesome service, i am fully satisfied on those service,
                                            theay are really like a super man</p>
                                        <ul class="star">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="user-details text-right">
                                        <h3 class="name">Jone Smith</h3><span>Front End Developer</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial clearfix">
                                    <div class="content">
                                        <div class="testi-thumb"><img src="<?php echo e(asset('public/frontend')); ?>/media/testimonial/5.jfif" alt="Testi"></div>
                                        <p class="text-dark">heay are provided awesome service, i am fully satisfied on those service,
                                            theay are really like a super man</p>
                                        <ul class="star">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="user-details text-right">
                                        <h3 class="name">Jone Smith</h3><span>Front End Developer</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial clearfix">
                                    <div class="content">
                                        <div class="testi-thumb"><img src="<?php echo e(asset('public/frontend')); ?>/media/testimonial/2.jpg" alt="Testi"></div>
                                        <p class="text-dark">heay are provided awesome service, i am fully satisfied on those service,
                                            theay are really like a super man</p>
                                        <ul class="star">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="user-details text-right">
                                        <h3 class="name">Jone Smith</h3><span>Front End Developer</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testi-pagination text-center" data-swiper="pagination"></div>
            </div>
        </section>



        <?php echo $__env->make('frontend.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        



        
        <section id="blog">
            <div class="container">
                <h2 class="section-title text-center wow animated fadeInUp" data-wow-delay="0ms">Latest News</h2>
                <p class="sub-title text-center wow animated fadeInUp" data-wow-delay="200ms">Here i show our main
                    services you ca see this if you need, we are the boos of the constraction industry so you can order
                    any service without any hisitetion, why late :)</p>
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-grid wow animated fadeInLeft" data-wow-delay="300ms"
                            data-wow-duration="1500ms">
                            <div class="blog-thumb"><a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/blog/14.jfif" alt="blog thumb"></a>
                                <div class="post-meta clearfix"><a href="#" class="author"><i
                                            class="fa fa-user"></i>Admin</a> <a href="#" class="date"><i
                                            class="fa fa-clock-o"></i>23 Mar,2020</a></div>
                            </div>
                            <div class="blog-content">
                                <h3 class="blog-title"><a href="#">How to pre plan for a building Project</a>.</h3>
                                <p>At first you need a pencil and artboard then you need a parsonal assistent then you
                                    need sketch your whole plane, when complete your sketch please rivision it agein.
                                </p><a href="#" class="dt-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-grid wow animated fadeInLeft" data-wow-delay="500ms"
                            data-wow-duration="1500ms">
                            <div class="blog-thumb"><a href="#"><img style="width: 100%" src="<?php echo e(asset('public/frontend')); ?>/media/blog/2.jpg" alt="blog thumb"></a>
                                <div class="post-meta clearfix"><a href="#" class="author"><i
                                            class="fa fa-user"></i>Admin</a> <a href="#" class="date"><i
                                            class="fa fa-clock-o"></i>23 Mar,2020</a></div>
                            </div>
                            <div class="blog-content">
                                <h3 class="blog-title"><a href="#">How to make a good house.</a></h3>
                                <p>At first you need a pencil and artboard then you need a parsonal assistent then you
                                    need sketch your whole plane, when complete your sketch please rivision it agein.
                                </p><a href="#" class="dt-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-grid wow animated fadeInLeft" data-wow-delay="700ms"
                            data-wow-duration="1500ms">
                            <div class="blog-thumb"><a href="#"><img src="<?php echo e(asset('public/frontend')); ?>/media/blog/15.jfif" alt="blog thumb"></a>
                                <div class="post-meta clearfix"><a href="#" class="author"><i
                                            class="fa fa-user"></i>Admin</a> <a href="#" class="date"><i
                                            class="fa fa-clock-o"></i>23 Mar,2020</a></div>
                            </div>
                            <div class="blog-content">
                                <h3 class="blog-title"><a href="#">How to calculate of house makeing cost</a></h3>
                                <p>At first you need a pencil and artboard then you need a parsonal assistent then you
                                    need sketch your whole plane, when complete your sketch please rivision it agein.
                                </p><a href="#" class="dt-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\escreative\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>